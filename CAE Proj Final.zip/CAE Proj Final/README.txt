GUI and Code built by Group 4:
Anthony Cummings
Blake Ezekie-White
Jackson Green
James Wilson